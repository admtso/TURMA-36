import { buscarPersonagens } from "./../service/finalspace.js"

async function montarLista(personagens) {
    try {
        let sectionLista = document.getElementById("lista")
        sectionLista.innerHTML = ""
        for(let i=0; i < personagens.length; i++) {
            sectionLista.innerHTML += `
            <div class="flex">
                <img src="${personagens[i].img_url}">
                <div class="info">
                    <p>ID: ${personagens[i].id}</p>
                    <p>Name: ${personagens[i].name}</p>
                    <p>Species: ${personagens[i].species}</p>
                    <p>Status: ${personagens[i].status}</p>
                </div>
            </div>
            `
        }
    } catch (error) {
        alert("Falha ao montar lista de personagens")
        console.log(error)
    }
}

async function listarTodosOsPersonagens() {
    try {
        let todosPersonagens = await buscarPersonagens()
        montarLista(todosPersonagens)
    } catch (error) {
        alert("Falha ao buscar personagens")
        console.log(error)
    }
}

async function filtrarPorNome() {
    try {
        let textoBusca = document.getElementById("inputBusca").value
        let todosPersonagens = await buscarPersonagens()
        let personagensFiltrados = todosPersonagens.filter((elemento) => {
            return elemento.name.toUpperCase().includes(textoBusca.toUpperCase())
        })
        montarLista(personagensFiltrados)
    } catch (error) {
        alert("Falha ao filtrar personagens")
        console.log(error)
    }
}

document.getElementById("btnBuscar").onclick = filtrarPorNome
document.getElementById("btnLimpar").onclick = listarTodosOsPersonagens
document.body.onload = listarTodosOsPersonagens