import { buscarPersonagens } from "./../service/finalspace.js"

async function lisatarPersonagens() {
    try {
        let personagens = await buscarPersonagens()
        let sectionLista = document.getElementById("lista")
        sectionLista.innerHTML = ""
        for(let i=0; i < personagens.length; i++) {
            sectionLista.innerHTML += `
            <div class="flex">
                <img src="${personagens[i].img_url}">
                <div class="info">
                    <p>ID: ${personagens[i].id}</p>
                    <p>Name: ${personagens[i].name}</p>
                    <p>Species: ${personagens[i].species}</p>
                    <p>Status: ${personagens[i].status}</p>
                </div>
            </div>
            `
        }
    } catch (error) {
        alert("Falha ao buscar personagens")
        console.log(error)
    }
}

document.body.onload = lisatarPersonagens