export async function buscarPersonagens() {
    try {
        let resposta = await fetch("https://finalspaceapi.com/api/v0/character/")
        return resposta.json()
    } catch (error) {
        throw error
    }
}